import React from 'react'; 


function Home() {
  return (
    <div>
      <h1>About Page</h1>
      <p>Welcome to the aboutpage.</p>
    </div>
  );
}

export default Home;
