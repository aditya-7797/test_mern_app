import React, { useState } from 'react';
import Axios from 'axios';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import Cookies from 'js-cookie';
import Header2 from '../components/Header2';

function BlogPost() {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [date, setDate] = useState('');
  const [summary, setSummary] = useState('');
  const [content, setContent] = useState('');
  const [img1, setImg1] = useState(null);
  const [img2, setImg2] = useState(null);
  const navigate = useNavigate();
  const user_email = Cookies.get('user_email'); // Retrieve user email from cookies

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    const user_email = Cookies.get('user_email'); // Fetch user_email from cookie again to ensure it's set

    if (!user_email) {
        alert('User not logged in or cookie not found');
        return;
    }

    formData.append('user_email', user_email.trim());  // Ensure to trim the email
    formData.append('title', title);
    formData.append('author', author);
    formData.append('date', date);
    formData.append('summary', summary);
    formData.append('content', content);
    if (img1) formData.append('img1', img1);
    if (img2) formData.append('img2', img2);

    try {
        const response = await Axios.post('http://localhost:5000/add_post', formData, {
            headers: {
                'Content-Type': 'multipart/form-data',
            },
        });
        alert(response.data.message || 'Blog posted successfully');
        navigate('/blogs');
    } catch (error) {
        console.error('Error posting blog:', error);
        alert(error.response?.data?.message || 'Error posting blog');
    }
};



  const handleFileChange = (e, setImage) => {
    const file = e.target.files[0];
    setImage(file);
  };

  return (
    <div className='cu'>
      <Header2 />

      <div className="container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-8">
            <h2 className="text-center mb-4">Create a New Blog Post</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="title" className="form-label">Blog Title</label>
                <input
                  type="text"
                  className="form-control"
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="author" className="form-label">Author</label>
                <input
                  type="text"
                  className="form-control"
                  id="author"
                  value={author}
                  onChange={(e) => setAuthor(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="date" className="form-label">Date</label>
                <input
                  type="date"
                  className="form-control"
                  id="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                />
              </div>
              <div className="mb-3">
                <label htmlFor="summary" className="form-label">Blog Summary</label>
                <textarea
                  className="form-control"
                  id="summary"
                  rows="2"
                  value={summary}
                  onChange={(e) => setSummary(e.target.value)}
                  required
                ></textarea>
              </div>
              <div className="mb-3">
                <label htmlFor="content" className="form-label">Blog Content</label>
                <textarea
                  className="form-control"
                  id="content"
                  rows="5"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  required
                ></textarea>
              </div>
              <div className="mb-3">
                <label htmlFor="img1" className="form-label">Blog Image 1</label>
                <input
                  type="file"
                  className="form-control"
                  id="img1"
                  onChange={(e) => handleFileChange(e, setImg1)}
                  accept="image/*"
                />
              </div>
              <div className="mb-3">
                <label htmlFor="img2" className="form-label">Blog Image 2</label>
                <input
                  type="file"
                  className="form-control"
                  id="img2"
                  onChange={(e) => handleFileChange(e, setImg2)}
                  accept="image/*"
                />
              </div>
              <button type="submit" className="btn btn-success">Post Blog</button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default BlogPost;
