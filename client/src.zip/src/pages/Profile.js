import React from 'react';
import Header2 from '../components/Header2';

const Profile = () => {
  return (
    <div>
      <Header2/>
    </div>
  );
}

export default Profile;
